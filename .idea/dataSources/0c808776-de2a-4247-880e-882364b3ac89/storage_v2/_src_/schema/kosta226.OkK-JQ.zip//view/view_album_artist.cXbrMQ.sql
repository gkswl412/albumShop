create view view_album_artist as
select `kosta226`.`album_artist`.`id`              AS `id`,
       `kosta226`.`album_artist`.`album_id`        AS `album_id`,
       `kosta226`.`album_artist`.`artist_id`       AS `artist_id`,
       `kosta226`.`album_artist`.`artist_group_id` AS `artist_group_id`,
       `kosta226`.`album_artist`.`album_artist`    AS `album_artist`,
       `a`.`name`                                  AS `name`
from (`kosta226`.`album_artist`
         join `kosta226`.`artist` `a` on ((`kosta226`.`album_artist`.`artist_id` = `a`.`id`)))
union all
select `kosta226`.`album_artist`.`id`              AS `id`,
       `kosta226`.`album_artist`.`album_id`        AS `album_id`,
       `kosta226`.`album_artist`.`artist_id`       AS `artist_id`,
       `kosta226`.`album_artist`.`artist_group_id` AS `artist_group_id`,
       `kosta226`.`album_artist`.`album_artist`    AS `album_artist`,
       `ag`.`name`                                 AS `name`
from (`kosta226`.`album_artist`
         join `kosta226`.`artist_group` `ag`
              on ((`kosta226`.`album_artist`.`artist_group_id` = `ag`.`id`)))
order by `id`;

