create view view_cart as
select `kosta226`.`cart_detail`.`cart_id`  AS `cart_id`,
       `kosta226`.`cart`.`user_id`         AS `user_id`,
       `kosta226`.`cart_detail`.`album_id` AS `album_id`,
       `kosta226`.`cart_detail`.`quantity` AS `quantity`
from (`kosta226`.`cart`
         join `kosta226`.`cart_detail`
              on ((`kosta226`.`cart`.`id` = `kosta226`.`cart_detail`.`cart_id`)));

